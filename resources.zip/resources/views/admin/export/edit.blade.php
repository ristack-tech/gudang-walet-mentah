@extends('layouts.app')

@section('title', 'Edit Export Barang')

@section('content')
<div class="bg-gray-50 min-h-screen">
    <div class="w-full px-4 sm:px-6 lg:px-8 py-8">
        
        <div class="mb-6 flex justify-between items-center max-w-5xl mx-auto">
            <a href="{{ route('export.index') }}"
                class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-200 shadow-sm">
                <svg class="w-4 h-4 mr-2 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
                </svg>
                Daftar Export
            </a>
        </div>

        <div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden max-w-5xl mx-auto">
            <div class="px-6 py-5 border-b border-gray-100">
                <h2 class="text-lg font-medium text-gray-900">Edit Export Barang</h2>
            </div>
            
            <form action="{{ route('export.update', $export->id) }}" method="POST" class="p-6">
                @csrf
                @method('PUT')
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-6 mb-6">
                    <!-- Tanggal -->
                    <div>
                        <label for="tanggal_transfer" class="block text-sm font-medium text-gray-700 mb-1">
                            Tanggal <span class="text-red-500">*</span>
                        </label>
                        <input type="date" name="tanggal_transfer" id="tanggal_transfer"
                            class="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-sm @error('tanggal_transfer') border-red-300 @enderror"
                            value="{{ old('tanggal_transfer', $export->tanggal_transfer) }}" required>
                        @error('tanggal_transfer')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Nama Barang -->
                    <div>
                        <label for="stok_barang_jadi_detail_id" class="block text-sm font-medium text-gray-700 mb-1">
                            Nama Barang <span class="text-red-500">*</span>
                        </label>
                        <select name="stok_barang_jadi_detail_id" id="stok_barang_jadi_detail_id"
                            class="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-sm @error('stok_barang_jadi_detail_id') border-red-300 @enderror" required>
                            <option value="">-- Pilih Nama Barang --</option>
                            @foreach($availableStocks as $stok)
                                <option value="{{ $stok['id'] }}" 
                                    data-berat="{{ $stok['available_berat'] ?? 0 }}"
                                    data-pcs="{{ $stok['available_pcs'] ?? 0 }}"
                                    {{ old('stok_barang_jadi_detail_id', $export->stok_barang_jadi_detail_id) == $stok['id'] ? 'selected' : '' }}>
                                    {{ $stok['nama_barang'] }}
                                </option>
                            @endforeach
                        </select>
                        <p id="stok_info" class="text-xs text-blue-600 mt-1 hidden"></p>
                        @error('stok_barang_jadi_detail_id')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Berat -->
                    <div>
                        <label for="berat" class="block text-sm font-medium text-gray-700 mb-1">
                            Berat (Gram) <span class="text-red-500">*</span>
                        </label>
                        <input type="number" step="0.01" name="berat" id="berat"
                            class="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-sm @error('berat') border-red-300 @enderror"
                            value="{{ old('berat', $export->berat) }}" placeholder="" required>
                        @error('berat')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Pcs -->
                    <div>
                        <label for="pcs" class="block text-sm font-medium text-gray-700 mb-1">
                            Pcs <span class="text-red-500">*</span>
                        </label>
                        <input type="number" name="pcs" id="pcs"
                            class="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-sm @error('pcs') border-red-300 @enderror"
                            value="{{ old('pcs', $export->pcs) }}" placeholder="" required>
                        @error('pcs')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Box -->
                    <div>
                        <label for="box" class="block text-sm font-medium text-gray-700 mb-1">
                            Box <span class="text-red-500">*</span>
                        </label>
                        <input type="number" name="box" id="box"
                            class="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-sm @error('box') border-red-300 @enderror"
                            value="{{ old('box', $export->box) }}" placeholder="" required>
                        @error('box')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Harga -->
                    <div>
                        <label for="harga" class="block text-sm font-medium text-gray-700 mb-1">
                            Harga <span class="text-red-500">*</span>
                        </label>
                        <input type="number" step="0.01" name="harga" id="harga"
                            class="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-sm @error('harga') border-red-300 @enderror"
                            value="{{ old('harga', $export->harga) }}" placeholder="" required>
                        @error('harga')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div>
                </div>

                <div class="flex justify-end pt-6 mt-4 border-t border-gray-100">
                    <button type="submit"
                        class="px-5 py-2.5 bg-blue-500 hover:bg-blue-600 text-white rounded-md text-sm font-medium transition duration-200 shadow-sm flex items-center">
                        Simpan Perubahan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const barangSelect = document.getElementById('stok_barang_jadi_detail_id');
        const beratInput = document.getElementById('berat');
        const pcsInput = document.getElementById('pcs');
        const stokInfo = document.getElementById('stok_info');

        function updateMaxLimits() {
            const selectedOption = barangSelect.options[barangSelect.selectedIndex];
            if (selectedOption.value) {
                const maxBerat = parseFloat(selectedOption.getAttribute('data-berat')) || 0;
                const maxPcs = parseInt(selectedOption.getAttribute('data-pcs')) || 0;
                
                beratInput.max = maxBerat;
                pcsInput.max = maxPcs;
                
                stokInfo.textContent = `Stok Clop Tersedia: ${maxBerat}g, ${maxPcs} Pcs`;
                stokInfo.classList.remove('hidden');
                
                // If user entered more than max, restrict it automatically
                if(parseFloat(beratInput.value) > maxBerat) beratInput.value = maxBerat;
                if(parseInt(pcsInput.value) > maxPcs) pcsInput.value = maxPcs;
            } else {
                beratInput.removeAttribute('max');
                pcsInput.removeAttribute('max');
                stokInfo.classList.add('hidden');
            }
        }

        barangSelect.addEventListener('change', updateMaxLimits);
        
        // initialize on load in case of old input
        if (barangSelect.value) {
            updateMaxLimits();
        }
        
        // Ensure manual typing doesn't exceed max
        beratInput.addEventListener('input', function() {
            if (this.max && parseFloat(this.value) > parseFloat(this.max)) {
                this.value = this.max;
            }
        });
        
        pcsInput.addEventListener('input', function() {
            if (this.max && parseInt(this.value) > parseInt(this.max)) {
                this.value = this.max;
            }
        });
    });
</script>
@endpush
@endsection
