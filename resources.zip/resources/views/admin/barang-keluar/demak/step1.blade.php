@extends('layouts.app')

@section('title', 'Tambah Barang Keluar Demak - Step 1')

@section('content')
    <div class="bg-gray-50 min-h-screen py-8">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            
            <!-- Header Section -->
            <div class="flex justify-between items-start mb-6">
                <div>
                    <h2 class="text-2xl font-bold text-gray-900">Tambah Barang Keluar Demak</h2>
                    <p class="text-gray-500 text-sm mt-1">Isi informasi pengiriman dan partai.</p>
                </div>
                <a href="{{ route('barang-keluar.demak.index') }}" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-200 shadow-sm">
                    <svg class="w-4 h-4 mr-2 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
                    </svg>
                    Kembali
                </a>
            </div>

            <!-- Flow Indicator Box -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 mb-6 p-6">
                <div class="flex items-center justify-center">
                    <!-- Step 1 -->
                    <div class="flex flex-col items-center">
                        <div class="w-10 h-10 flex items-center justify-center rounded-full bg-blue-600 text-white font-bold text-lg mb-2 shadow-sm">1</div>
                        <span class="text-sm font-medium text-blue-600">Info Utama</span>
                    </div>
                    
                    <!-- Line -->
                    <div class="w-32 sm:w-48 border-t-2 border-gray-200 mx-4 mb-6"></div>

                    <!-- Step 2 -->
                    <div class="flex flex-col items-center opacity-60">
                        <div class="w-10 h-10 flex items-center justify-center rounded-full bg-gray-100 text-gray-500 font-bold text-lg mb-2 border-2 border-white shadow-sm ring-1 ring-gray-200">2</div>
                        <span class="text-sm font-medium text-gray-500">Detail Barang</span>
                    </div>
                </div>
            </div>

            <!-- Form Box -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <div class="p-6 sm:p-8">
                    <form action="{{ route('barang-keluar.demak.store-step1') }}" method="POST">
                        @csrf
                        <div class="space-y-6 max-w-3xl">
                            <div>
                                <label for="tanggal_kirim" class="block text-sm font-medium text-gray-700 mb-1">Tanggal Kirim <span class="text-red-500">*</span></label>
                                <input type="date" name="tanggal_kirim" id="tanggal_kirim" required
                                    value="{{ session('demak_step1.tanggal_kirim', date('Y-m-d')) }}"
                                    class="block w-full border border-gray-300 rounded-lg shadow-sm py-2.5 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition duration-200 @error('tanggal_kirim') border-red-500 @enderror">
                                @error('tanggal_kirim')
                                    <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                                @enderror
                            </div>

                            <div>
                                <label for="partai_id" class="block text-sm font-medium text-gray-700 mb-1">Partai <span class="text-red-500">*</span></label>
                                <select name="partai_id" id="partai_id" required class="block w-full border border-gray-300 rounded-lg shadow-sm py-2.5 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition duration-200 @error('partai_id') border-red-500 @enderror">
                                    <option value="">-- Pilih Partai --</option>
                                    @foreach($partais as $partai)
                                        <option value="{{ $partai->id }}" {{ session('demak_step1.partai_id') == $partai->id ? 'selected' : '' }}>
                                            {{ $partai->nama_partai }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('partai_id')
                                    <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
                                @enderror
                            </div>
                        </div>

                        <div class="mt-8 pt-6 border-t border-gray-100 flex justify-end">
                            <button type="submit" class="bg-blue-600 border border-transparent rounded-lg shadow-sm py-2.5 px-6 inline-flex justify-center text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-200">
                                Lanjut ke Step 2
                                <svg class="ml-2 -mr-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" /></svg>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
        </div>
    </div>
@endsection
