<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Warna extends Model
{
    use HasFactory;

    protected $table = 'warna';

    protected $fillable = [
        'kode_warna',
        'warna',
    ];

    public function barangKeluarDemak()
    {
        return $this->hasMany(BarangKeluarDemak::class, 'warna_id');
    }
}
